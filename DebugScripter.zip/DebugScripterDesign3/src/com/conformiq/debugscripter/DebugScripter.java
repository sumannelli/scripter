package com.conformiq.debugscripter;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.conformiq.creator.CreatorAction;
import com.conformiq.creator.CreatorActionStep;
import com.conformiq.creator.CreatorAnnotated;
import com.conformiq.creator.CreatorExternalCircumstanceStep;
import com.conformiq.creator.CreatorType;
import com.conformiq.creator.CreatorValueWrapper;
import com.conformiq.creator.domain.business.value.CreatorBusinessAction;
import com.conformiq.creator.domain.business.value.CreatorBusinessAction.ParameterValueToken;
import com.conformiq.creator.domain.generic.CreatorCustomAction;
import com.conformiq.creator.domain.generic.CreatorCustomActionType;
import com.conformiq.creator.domain.generic.CreatorCustomActionType.FieldRefToken;
import com.conformiq.creator.domain.generic.CreatorCustomActionType.LiteralToken;
import com.conformiq.creator.domain.generic.CreatorCustomActionType.TextualRenderingToken;
import com.conformiq.creator.domain.generic.CreatorDateValue;
import com.conformiq.creator.domain.generic.CreatorEnumType;
import com.conformiq.creator.domain.generic.CreatorExternalInterface;
import com.conformiq.creator.domain.generic.CreatorGenericAction;
import com.conformiq.creator.domain.generic.CreatorGenericType;
import com.conformiq.creator.domain.generic.CreatorListType;
import com.conformiq.creator.domain.generic.CreatorMessageAction;
import com.conformiq.creator.domain.generic.CreatorMessageType;
import com.conformiq.creator.domain.generic.CreatorStructuredType;
import com.conformiq.creator.domain.generic.CreatorTypeField;
import com.conformiq.creator.domain.generic.value.CreatorBooleanValue;
import com.conformiq.creator.domain.generic.value.CreatorCustomActionValue;
import com.conformiq.creator.domain.generic.value.CreatorEnumValue;
import com.conformiq.creator.domain.generic.value.CreatorListValue;
import com.conformiq.creator.domain.generic.value.CreatorNumberValue;
import com.conformiq.creator.domain.generic.value.CreatorOmittedValue;
import com.conformiq.creator.domain.generic.value.CreatorStringValue;
import com.conformiq.creator.domain.generic.value.CreatorStructuredValue;
import com.conformiq.creator.domain.generic.value.CreatorValue;
import com.conformiq.creator.domain.generic.value.CreatorValueField;
import com.conformiq.creator.domain.gui.CreatorContainerWidget;
import com.conformiq.creator.domain.gui.CreatorDropdown;
import com.conformiq.creator.domain.gui.CreatorGuiAction;
import com.conformiq.creator.domain.gui.CreatorGuiTableRowAction;
import com.conformiq.creator.domain.gui.CreatorTextBox;
import com.conformiq.creator.domain.gui.CreatorWidget;
import com.conformiq.creator.domain.gui.CreatorWidget.Type;
import com.conformiq.creator.domain.gui.value.CreatorBasicWidgetValue;
import com.conformiq.creator.domain.gui.value.CreatorCalendarValue;
import com.conformiq.creator.domain.gui.value.CreatorCheckBoxValue;
import com.conformiq.creator.domain.gui.value.CreatorContainerWidgetValue;
import com.conformiq.creator.domain.gui.value.CreatorDropdownValue;
import com.conformiq.creator.domain.gui.value.CreatorLabelValue;
import com.conformiq.creator.domain.gui.value.CreatorListBoxValue;
import com.conformiq.creator.domain.gui.value.CreatorPopupValue;
import com.conformiq.creator.domain.gui.value.CreatorRadioButtonGroupValue;
import com.conformiq.creator.domain.gui.value.CreatorTabValue;
import com.conformiq.creator.domain.gui.value.CreatorTableValue;
import com.conformiq.creator.domain.gui.value.CreatorTextBoxValue;
import com.conformiq.creator.domain.gui.value.CreatorWidgetStatus;
import com.conformiq.creator.domain.gui.value.CreatorWidgetValue;
import com.conformiq.designer.Checkpoint;
import com.conformiq.designer.Checkpoint.CheckpointType;
import com.conformiq.designer.CheckpointBase;
import com.conformiq.designer.CheckpointGroup;
import com.conformiq.designer.DesignConfiguration;
import com.conformiq.designer.ExternalMessageStep;
import com.conformiq.designer.ExternalRequirement;
import com.conformiq.designer.NameFragmentStep;
import com.conformiq.designer.NarrativeStep;
import com.conformiq.designer.PluginConfiguration;
import com.conformiq.designer.ProgressNotificationSink;
import com.conformiq.designer.Project;
import com.conformiq.designer.QMLMetadata;
import com.conformiq.designer.QueryScriptBackend;
import com.conformiq.designer.Requirement;
import com.conformiq.designer.ScenarioStep;
import com.conformiq.designer.TestCase;
import com.conformiq.designer.TestStep;
import com.conformiq.designer.TraceStep;
import com.conformiq.designer.TracepointStep;
import com.conformiq.qtronic2.Annotation;
import com.conformiq.qtronic2.NotificationSink.Severity;
import com.conformiq.qtronic2.QMLArray;
import com.conformiq.qtronic2.QMLOptional;
import com.conformiq.qtronic2.QMLRecord;
import com.conformiq.qtronic2.QMLRecordField;
import com.conformiq.qtronic2.QMLRecordType;
import com.conformiq.qtronic2.QMLRecordTypeField;
import com.conformiq.qtronic2.QMLValue;

public class DebugScripter implements QueryScriptBackend {

	PrintStream out;
	Map<String, Object> mp = new LinkedHashMap<>();

	@Override
	public void preRender(PluginConfiguration conf) {

	}

	String folderPath = "";
	{

	}

	int rowCount = 0;

	int columnCount = 0;

	@Override
	public boolean renderTests(PluginConfiguration configuration, Project project, DesignConfiguration dc,
			ProgressNotificationSink ns) {

		configuration.getHostConfigurator().setPreconditionsEnabled(
				Boolean.parseBoolean(configuration.getConfigurationOption("General.Preconditions")));

		String filename = configuration.getConfigurationOption("General.Output file");
		folderPath = filename;
		ns.notify(Severity.INFO, "----->" + filename);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = null;

		try {
			sheet = workbook.createSheet("Example");

		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		if (!filename.isEmpty())
			try {
				out = new PrintStream(filename, "UTF-8");
			} catch (FileNotFoundException | UnsupportedEncodingException e) {
				ns.notify(Severity.ERROR, String.format("Error opening output file: %s", e.getMessage()));
				return false;
			}
		else

			out = System.out;

		out.println("Design configuration: " + dc.getName());
		out.println("  Identifier: " + dc.getIdentifier());

		out.println();

		String testCaseName = "";

		for (TestCase tc : dc.getTestCases()) {
			columnCount = 0;

			Set<String> keys = mp.keySet();

			Row row = sheet.createRow(rowCount);
			
			Cell cellRow = row.createCell(columnCount);
			
			cellRow.setCellValue((String) tc.getName());

			
			rowCount++;
			Row headerRow = sheet.createRow(rowCount);

			debugPrint(0, "Test case: " + tc.getName());
			
			
			rowCount++;
			
			Row valuesRow = sheet.createRow(rowCount);
			
			
			
			rowCount++;
			 
			Row empty = sheet.createRow(rowCount);
			rowCount++;
			testCaseName = tc.getName();

			TestCase precond = tc.getPreconditionTest();
			if (precond != null)
				debugPrint(1, "Precondition: " + precond.getName());
			debugPrint(1, "Priority: " + tc.getPriority());

			for (TestStep step : tc.getTestSteps()) {
				debugPrint(1, "Test step: " + step.getType());
				
				switch (step.getType()) {
				/*
				 * case CHECKPOINT: debugCheckpoint(((CheckpointStep)step).getCheckpoint(), 2);
				 * break;
				 */
				case CREATOR_ACTION:
					try {
						debugCreatorAction(((CreatorActionStep) step).getAction(), 3);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case EXTERNAL_MESSAGE:
					debugDataStructure(((ExternalMessageStep) step).getMessage(), 3);
					break;
				case EXECUTION_INFO:
					if (step instanceof ScenarioStep)
						debugPrint(2, "Scenario: " + ((ScenarioStep) step).getScenario());
					else if (step instanceof NarrativeStep)
						debugPrint(2, "Narrative: " + ((NarrativeStep) step).getNarrative());
					else if (step instanceof NameFragmentStep)
						debugPrint(2, "Name fragment: " + ((NameFragmentStep) step).getNameFragment());
					else if (step instanceof TracepointStep)
						debugPrint(2, "Tracepoint: " + ((TracepointStep) step).getTracepoint());
					else if (step instanceof TraceStep)
						debugPrint(2, "Trace: " + ((TraceStep) step).getTrace());
					else
						debugPrint(2, "Unknown subtype: " + step.getClass().getSimpleName());
					break;
				case CREATOR_EXTERNAL_CIRCUMSTANCE:
					debugCreatorExternalCircumstance((CreatorExternalCircumstanceStep) step, 2);
					break;
				default:
					break;
				}
				
				for(Entry<String, Object> mapEntry:mp.entrySet()) {
					
					Cell cell = headerRow.createCell(columnCount);
					cell.setCellValue(mapEntry.getKey());
					
					 Cell cellValue = valuesRow.createCell(columnCount);
					 cellValue.setCellValue((String) mapEntry.getValue());
					 
					Cell empV =  empty.createCell(columnCount);
					empV.setCellValue("");
					 
					 columnCount++;
				}
				
				mp.clear();
			}

		//	columnCount = 0;

			/*Set<String> keys = mp.keySet();

			Row row = sheet.createRow(rowCount);
			
			Cell cellRow = row.createCell(columnCount);
			
			cellRow.setCellValue((String) tc.getName());

			Row row1 = sheet.createRow(++rowCount);

			for (Object key : keys) {

				Cell cell = row1.createCell(columnCount++);
				
				cell.setCellValue((String) key);

			}
			
			Row row2 = sheet.createRow(++rowCount);
			int count = 0;
			for(Map.Entry m:mp.entrySet())
			{  
				
				   Cell cell = row2.createCell(count++);
				   cell.setCellValue((String) m.getValue());
				   
				  }  
			out.println("The map is " + mp);*/
			/*mp.clear();
			
			rowCount++;*/
			

		}
		out.println();

		out.println("--------- Uncovered checkpoints:");

		out.println("--------- Total screens are :" + scree);

		out.println("Total text names are " + textbox);

		// mp.put(testCaseName, "");

		

		try {
			FileOutputStream outputStream = new FileOutputStream(filename + "JavaBooks.xlsx");
			workbook.write(outputStream);
			workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Checkpoint cp : dc.getUncoveredCheckpoints()) {
			debugPrint(0, "Uncovered:");
			debugCheckpoint(cp, 1);
		}

		return true;
	}

	private void debugCreatorExternalCircumstance(CreatorExternalCircumstanceStep step, int indent) {
		debugPrint(indent, "External Circumstance: " + step.getCircumstance());
		mp.put("CREATOR_EXTERNAL_CIRCUMSTANCE", step.getCircumstance());
	}

	private void debugCreatorAction(CreatorAction action, int indent) throws IOException {
		switch (action.getActionDomain()) {
		case GENERIC:
			debugCreatorGenericAction((CreatorGenericAction) action, indent);
			break;
		case GUI:
			debugCreatorGuiAction((CreatorGuiAction) action, indent);
			break;
		case BUSINESS:
			debugCreatorBusinessAction((CreatorBusinessAction) action, indent);
			break;
		}
	}
	
	String businessNameParameter = "";
	String businessActivityValue = "";
	private void debugCreatorBusinessAction(CreatorBusinessAction action, int indent) {
		debugPrint(indent, "Business Action:");
		debugPrint(indent + 1, "Direction: " + action.getActionType());
		debugPrint(indent + 1, "Rendering: " + renderBusinessAction(action));
		// Output also the token structure to make the parameter names visible.
		for (CreatorBusinessAction.TextualRenderingToken t : action.getTextualRendering()) {
			switch (t.getToken()) {
			case PARAMETER_VALUE:
				ParameterValueToken p = (CreatorBusinessAction.ParameterValueToken) t;
				
				debugPrint(indent + 2, "Parameter: " + p.getParameterName());
				businessNameParameter = p.getParameterName();
				debugPrint(indent + 3, "Value: " + printCreatorValue(p.getParameterValue()));
				out.println(p.getParameterName()+"================>In parameter value");
				out.println(p.getParameterValue().get().toString()+" ============>in parameter value");
				mp.put(p.getParameterName(), p.getParameterValue().get().toString());
				break;
			case LITERAL:
				debugPrint(indent + 2, "Literal: " + ((CreatorBusinessAction.LiteralToken) t).getText());
				
				out.println("the literal is =======>"+((CreatorBusinessAction.LiteralToken) t).getText());
				
				break;
			}
		}
	}
	String btn = "";

	private void debugCreatorAnnotations(int indent, CreatorAnnotated annotated) {
		debugMap(indent, "Annotations:", annotated.getAnnotations());
	}

	List<String> arr = new ArrayList<String>();

	private void debugCreatorGuiAction(CreatorGuiAction action, int indent) throws IOException {

		Map<String, Object> m = new HashMap<String, Object>();

		debugPrint(indent, "Action: " + action.getActionKind());
		
		
		
		List<CreatorWidget> context = action.getContext();

		out.println(" The action is " + action.getActionKind().DISPLAY);

		if (action.getActionKind().DISPLAY.toString().equals("DISPLAY")) {
			
			out.println(" The action is " + action.getActionType().toString());

			out.println(" The action is " + action.getActionType());

			arr.add(action.getActionType().toString());
		}
		if (!context.isEmpty()) {
			String context_text = String.format("%s (%s)", context.get(0).getName(), context.get(0).getType());

			m.put(context.get(0).getName(), context.get(0).getType());

			if (context.get(0).getType().equals("DISPLAY")) {

				arr.add(context.get(0).getName());

				out.println();

			}

			for (int i = 1; i < context.size(); i++)
				context_text += String.format(" -> %s (%s)", context.get(i).getName(), context.get(i).getType());

			debugPrint(indent + 1, "Context: " + context_text);
		}

		if (action instanceof CreatorGuiTableRowAction) {
			debugPrint(indent + 1, "Row:");

			for (CreatorWidgetValue value : ((CreatorGuiTableRowAction) action).getTargetRow().getValues())
				debugCreatorWidgetValue(value, indent + 2);
		}

		debugCreatorWidgetValue(action.getValue(), indent + 1);
	}
	static int i = 0;
	static private <T> String printCreatorValue(CreatorValueWrapper<T> value) {
		if (value.isDontCare()) {
			i= 1;
			return "DontCare";
		}
			
		
		return value.get().toString();
	}

	List<String> textbox = new ArrayList<String>();


	private void debugCreatorWidgetValue(CreatorWidgetValue value, int indent) {

		debugPrint(indent, String.format("Widget: %s (%s)", value.getWidget().getName(), value.getWidget().getType()));

		/*out.println("*********************************************************");

		out.println(value.getWidget().getType().toString() + " My widget name is  ");
		out.println(value.getWidget().getType() + " My widget type is  ");
*/
		if (value.getWidget().getType().toString().equalsIgnoreCase("SCREEN")) {

			scree.add(value.getWidget().getName());

		}
		value.getWidget().getType();
		if (value.getWidget().getType().equals(Type.HYPERLINK)) {
			
			mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
		}
		if (value.getWidget().getType().equals((Type.CLICKCHOICE) )){
			
			mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
		}
		if(value.getWidget().getType().equals((Type.MOUSEOVERCHOICE) )) {
			mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
		}
		
		
		
	/*	if(value.getWidget().getType().equals((Type.BUTTON) )) {
		
			 //printCreatorValue(((CreatorBasicWidgetValue) value).getStatus());
			 
			 out.println("/////////////////////////////////");
	if( i != 0) {

		out.println("*****************************");
		out.println("the status is no dontcare");

		out.println("*****************************");
		mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
	}
		
		
		
		
		if (!().equals("DontCare"))) {
			
				mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
				
				
		
		}}*/
			
		
		
		
		
		if (value instanceof CreatorTextBoxValue) {

			debugPrint(indent + 1, "Text: " + printCreatorValue(((CreatorTextBoxValue) value).getText()));
			
			
		
			
			// out.println("the textbox value is
			// "+printCreatorValue(((CreatorTextBoxValue)value).getText().isDontCare()));

			if (!((CreatorTextBoxValue) value).getText().isDontCare()) {
			
				textbox.add(value.getWidget().getName());
				CreatorValueWrapper<String> mm = ((CreatorTextBoxValue) value).getText();

				
				mp.put(value.getWidget().getName(), printCreatorValue(((CreatorTextBoxValue) value).getText()));

				
			}
		} 
		
	
		
		
		else if (value instanceof CreatorListBoxValue) {
			CreatorValueWrapper<List<String>> list = ((CreatorListBoxValue) value).getSelectedValues();

			if (list.isDontCare())
				debugPrint(indent + 1, "Selected: DontCare");
			else {
				for (String selected : list.get())
					debugPrint(indent + 1, "Selected: " + selected);
			}
		} else if (value instanceof CreatorLabelValue) {

			debugPrint(indent + 1, "Text: " + printCreatorValue(((CreatorLabelValue) value).getText()));
			if (!((CreatorLabelValue) value).getText().isDontCare()) {

				textbox.add(value.getWidget().getName());
				mp.put(value.getWidget().getName(), ((CreatorLabelValue) value).getText().get().toString());

			}

		} else if (value instanceof CreatorCheckBoxValue) {
			debugPrint(indent + 1, "Checked: " + printCreatorValue(((CreatorCheckBoxValue) value).isChecked()));
		} else if (value instanceof CreatorRadioButtonGroupValue) {
			CreatorValueWrapper<CreatorWidget> selected = ((CreatorRadioButtonGroupValue) value).getSelected();

			if (selected.isDontCare())
				debugPrint(indent + 1, "Selected: DontCare");
			else {
				debugPrint(indent + 1, "Selected: " + selected.get().getName());
				mp.put(value.getWidget().getName(), ((CreatorRadioButtonGroupValue) value).getSelected().get().getName().toString() );
			}
		} else if (value instanceof CreatorCalendarValue) {
			CreatorValueWrapper<Date> date = ((CreatorCalendarValue) value).getDate();

			if (date.isDontCare())
				debugPrint(indent + 1, "Date: DontCare");
			else
				debugPrint(indent + 1, "Date: " + new SimpleDateFormat("dd-MM-yyyy").format(date.get()));
		} else if (value instanceof CreatorDropdownValue) {
			debugPrint(indent + 1, "Selected: " + printCreatorValue(((CreatorDropdownValue) value).getSelected()));

			if (!((CreatorDropdownValue) value).getSelected().isDontCare()) {
				textbox.add(value.getWidget().getName());
				mp.put(value.getWidget().getName(), ((CreatorDropdownValue) value).getSelected().get().toString());

			}

		} else if (value instanceof CreatorTableValue) {
			int count = 1;
			for (CreatorTableValue.Row row : ((CreatorTableValue) value).getRows()) {
				debugPrint(indent + 1, String.format("Row %d:", count++));

				for (CreatorWidgetValue row_value : row.getValues())
					debugCreatorWidgetValue(row_value, indent + 2);
			}
		} else if (value instanceof CreatorTabValue) {
			debugPrint(indent + 1, String.format("Selected: %b", ((CreatorTabValue) value).isSelected()));
		} else if (value instanceof CreatorPopupValue) {
			debugPrint(indent + 1, String.format("Text: %s", printCreatorValue(((CreatorPopupValue) value).getText())));
		}

		if (value instanceof CreatorContainerWidgetValue) {
			for (CreatorWidgetValue child : ((CreatorContainerWidgetValue) value).getChildren())
				debugCreatorWidgetValue(child, indent + 1);
		} else if (value instanceof CreatorBasicWidgetValue) {
			debugPrint(indent + 1, "Status: " + printCreatorValue(((CreatorBasicWidgetValue) value).getStatus()));
			printCreatorValue(((CreatorBasicWidgetValue) value).getStatus());
		out.println("****************************");
		out.println(printCreatorValue(((CreatorBasicWidgetValue) value).getStatus()));
		if(value.getWidget().getType().equals((Type.BUTTON) )) {
		if( i != 0) {
			mp.put(value.getWidget().getType().toString(), value.getWidget().getName());
		}
			out.println("8888888888888");
		}
		
		}
	}

	private void debugCreatorGenericAction(CreatorGenericAction action, int indent) {
		debugPrint(indent, "Action: " + action.getActionKind());
		switch (action.getActionKind()) {
		case CUSTOM:
			CreatorCustomAction customaction = (CreatorCustomAction) action;
			debugPrint(indent, "Direction: " + customaction.getActionType());
			
		
			
			
			
			debugCreatorInterface(customaction.getInterface(), indent);
			
			 debugCreatorValue(customaction.getCustomAction(), indent);
			
		
	
			String customValue = renderCustomAction(customaction.getCustomAction());
			
			mp.put(customaction.getCustomAction().getType().getName(), customValue);
			
		
			
			debugPrint(indent, "Rendering: " + renderCustomAction(customaction.getCustomAction()));
			break;
		case MESSAGE:
			CreatorMessageAction msgaction = (CreatorMessageAction) action;
			debugPrint(indent, "Direction: " + msgaction.getActionType());
			debugCreatorInterface(msgaction.getInterface(), indent);
			debugCreatorValue(msgaction.getMessage(), indent);
			break;
		}
	}

	private String renderBusinessAction(CreatorBusinessAction action) {
		String rendering = "";
		
		for (CreatorBusinessAction.TextualRenderingToken t : action.getTextualRendering()) {

			
			switch (t.getToken()) {
			
			case PARAMETER_VALUE:
				
				
				rendering += ((CreatorBusinessAction.ParameterValueToken) t).getParameterValue().get();
				
				
				break;
			case LITERAL:
			
				
				rendering += ((CreatorBusinessAction.LiteralToken) t).getText();
			
				
				break;
			}
			
		
		}
		
		
	
		
		return rendering;
	}

	private String renderCustomAction(CreatorCustomActionValue custom) {
		String rendering = "";
		for (TextualRenderingToken token : ((CreatorCustomActionType) custom.getType()).getTextualRendering()) {
			switch (token.getToken()) {
			case FIELDREF:
				rendering += renderCreatorWrappedValue(
						custom.getFieldValue(((FieldRefToken) token).getField()).getValue());
				break;
			case LITERAL:
				rendering += ((LiteralToken) token).getText();
				break;
			}
		}

		return rendering;
	}

	private String renderCreatorWrappedValue(CreatorValueWrapper<CreatorValue> wrapped) {
		if (wrapped.isDontCare())
			return "DontCare";

		return renderCreatorValue(wrapped.get());
	}

	private String renderCreatorValue(CreatorValue value) {
		if (value instanceof CreatorOmittedValue)
			return "Omitted";
		else if (value instanceof CreatorNumberValue)
			return "" + ((CreatorNumberValue) value).getNumber();
		else if (value instanceof CreatorStringValue)
			return "\"" + ((CreatorStringValue) value).getString() + "\"";
		else if (value instanceof CreatorBooleanValue)
			return "" + ((CreatorBooleanValue) value).getBoolean();
		else if (value instanceof CreatorDateValue)
			return new SimpleDateFormat("dd-MM-yyyy").format(((CreatorDateValue) value).getDate()).toString();
		else if (value instanceof CreatorEnumValue)
			return ((CreatorEnumValue) value).getValue().toString();
		else
			return "Unknown (" + value + ")";
	}


	private void debugCreatorValue(CreatorValue value, int indent) {
		
		if (value.getType() != null) // XXX Why is this null sometimes?
			debugPrint(indent, "Type: " + value.getType().getName());

		if (value instanceof CreatorStructuredValue)
			debugCreatorStructuredValue((CreatorStructuredValue) value, indent);
		
		else if (value instanceof CreatorListValue)
			debugCreatorArrayValue((CreatorListValue) value, indent);
		else
			debugPrint(indent, "Value: " + renderCreatorValue(value));
	}

	private void debugCreatorWrappedValue(CreatorValueWrapper<CreatorValue> wrapped, int indent) {
		if (wrapped.isDontCare())
			debugPrint(indent, "Value: " + renderCreatorWrappedValue(wrapped));
		else
			debugCreatorValue(wrapped.get(), indent);
	}

	private void debugCreatorArrayValue(CreatorListValue value, int indent) {
		debugPrint(indent, "Values:");

		for (CreatorValueWrapper<CreatorValue> item : value.getContents())
			debugCreatorWrappedValue(item, indent + 1);
	}

	private void debugCreatorStructuredValue(CreatorStructuredValue value, int indent) {
		for (CreatorValueField field : value.getFields()) {
			String ns = field.getType().getNamespace();
			if (ns != null)
				debugPrint(indent + 1, String.format("Field: %s (%s)", field.getName(), ns));
			else
				debugPrint(indent + 1, "Field: " + field.getName());
			debugCreatorWrappedValue(field.getValue(), indent + 2);
		}
	}

	private void debugCreatorStructure(CreatorType type, int indent) {
		switch (type.getDomain()) {
		case GENERIC:
			debugCreatorGenericStructure((CreatorGenericType) type, indent);
			break;
		case GUI:
			debugCreatorGuiStructure((CreatorWidget) type, indent);
			break;
		case BUSINESS:
			throw new RuntimeException("Unexpected type metadata for BUSINESS domain");
		}
	}

	private void debugCreatorGuiStructure(CreatorWidget type, int indent) {
		debugPrint(indent, String.format("Widget: %s (%s, %s)", type.getName(), type.getType(), type.getDomain()));

		debugCreatorAnnotations(indent + 1, type);

		if (type instanceof CreatorTextBox)
			debugPrint(indent + 1, String.format("Kind: %s", ((CreatorTextBox) type).getKind()));
		else if (type instanceof CreatorDropdown) {
			for (String choice : ((CreatorDropdown) type).getChoices())
				debugPrint(indent + 1, String.format("Choice: %s", choice));
		}

		if (type instanceof CreatorContainerWidget) {
			for (CreatorWidget childtype : ((CreatorContainerWidget) type).getChildren())
				debugCreatorGuiStructure(childtype, indent + 1);
		}
	}

	private void debugCreatorGenericStructure(CreatorGenericType type, int indent) {
		if (type.getNamespace() != null)
			debugPrint(indent, String.format("Type: %s (%s) (%s, %s)", type.getName(), type.getNamespace(),
					type.getType(), type.getDomain()));
		else
			debugPrint(indent, "Type: " + type.getName() + " (" + type.getType() + ", " + type.getDomain() + ")");

		debugCreatorAnnotations(indent + 1, type);

		switch (type.getType()) {
		case ENUMERATION:
			for (String value : ((CreatorEnumType) type).getValues())
				debugPrint(indent + 1, "Value: " + value);
			break;
		case CUSTOMACTION: {
			CreatorCustomActionType custom = (CreatorCustomActionType) type;

			String rendering = "";
			for (TextualRenderingToken token : custom.getTextualRendering()) {
				switch (token.getToken()) {
				case FIELDREF:
					rendering += "<" + ((FieldRefToken) token).getField().getName() + ">";
					break;
				case LITERAL:
					rendering += ((LiteralToken) token).getText();
					break;
				}
			}

			debugPrint(indent + 1, "Rendering: " + rendering);
		} // FALLTHROUGH
		case MESSAGE: {
			CreatorMessageType message = (CreatorMessageType) type;

			for (CreatorExternalInterface iface : message.getInterfaces())
				debugCreatorInterface(iface, indent + 1);
		}
			break;
		case LIST:
			debugCreatorGenericStructure(((CreatorListType) type).getElementType(), indent + 2);
			break;
		default:
			break;
		}

		if (type instanceof CreatorStructuredType) {
			for (CreatorTypeField field : ((CreatorStructuredType) type).getFields()) {
				if (field.getNamespace() != null)
					debugPrint(indent + 1, String.format("Field: %s (%s)", field.getName(), field.getNamespace()));
				else
					debugPrint(indent + 1, "Field: " + field.getName());
				debugCreatorAnnotations(indent + 2, field);
				if (field.isOptional())
					debugPrint(indent + 2, "Optional");
				debugCreatorGenericStructure(field.getType(), indent + 2);
			}
		}
	}

	private void debugCreatorInterface(CreatorExternalInterface iface, int indent) {
		debugPrint(indent, "Interface: " + iface.getName());
		debugPrint(indent + 1, "Direction: " + iface.getDirection());
		debugCreatorAnnotations(indent + 1, iface);
	}

	private void debugStructure(QMLMetadata metaData) {
		for (QMLRecordType recordtype : metaData.getTypes()) {
			debugRecordStructure(recordtype, 0);
		}
	}

	private void debugRecordStructure(QMLRecordType recordtype, int indent) {
		debugPrint(indent, "Record: " + recordtype.getTypeName());
		debugPrint(indent + 1, "Identifier: " + recordtype.getTypeIdentifier());

		for (Annotation annotation : recordtype.getAnnotations().values()) {
			debugPrint(indent + 1, "Annotation: " + annotation);
		}

		for (QMLRecordTypeField fieldtype : recordtype.getFields()) {
			debugPrint(indent + 1, "Field: " + fieldtype.getFieldName());
			if (fieldtype.getType() instanceof QMLRecordType)
				debugRecordStructure((QMLRecordType) fieldtype.getType(), indent + 2);
			else
				debugPrint(indent + 2, "Type name: " + fieldtype.getTypeName());
			debugPrint(indent + 2, "Identifier: " + fieldtype.getFieldIdentifier());
			for (Annotation annotation : fieldtype.getAnnotations().values()) {
				debugPrint(indent + 2, "Annotation: " + annotation);
			}
		}

		for (QMLRecordType innertype : recordtype.getInnerTypes()) {
			debugRecordStructure(innertype, indent + 2);
		}
	}

	private void debugDataStructure(QMLValue value, int indent) {
		if (value instanceof QMLOptional) {
			QMLOptional optional = (QMLOptional) value;
			debugPrint(indent, "Optional:");
			if (optional.isPresent())
				debugDataStructure(optional.getValue(), indent + 2);
			else
				debugPrint(indent + 1, "omitted");
		} else if (value instanceof QMLRecord) {
			QMLRecord record = (QMLRecord) value;
			debugPrint(indent, "Record: " + record.getName());

			for (QMLRecordField field : record.getFields()) {
				debugPrint(indent + 1, "Field: " + field.getName());
				debugPrint(indent + 1, "Identifier: " + field.getIdentifier());
				debugDataStructure(field.getValue(), indent + 2);
			}
		} else if (value instanceof QMLArray) {
			debugPrint(indent, "Values:");

			for (QMLValue val : ((QMLArray) value).getValues())
				debugDataStructure(val, indent + 1);
		} else {
			debugPrint(indent, "Value: " + value);
		}
	}

	List<String> scree = new ArrayList<String>();

	private void debugCheckpoint(Checkpoint cp, int indent) {
		debugPrint(indent, "Checkpoint: " + cp.getShortName());

		debugPrint(indent + 1, "Identifier: " + cp.getIdentifier());
		debugPrint(indent + 1, "Type: " + cp.getType());
		debugPrint(indent + 1, "Full name: " + cp.getFullName());
		if (cp.getType() == CheckpointType.REQUIREMENT) {
			Requirement req = (Requirement) cp;
			debugPrint(indent + 1, "Requirement identifier: " + req.getRequirementIdentifier());
			debugPrint(indent + 1, "Requirement description: " + req.getRequirementDescription());
		}
		for (ExternalRequirement ext : cp.getExternalRequirements()) {
			debugPrint(indent + 1, "External requirement identifier: " + ext.getExternalIdentifier());
			debugPrint(indent + 2, "Provider identifier: " + ext.getProviderInfo().getIdentifier());
		}
		debugCheckpointBaseCommon(cp, indent + 1);

	}

	private void debugCheckpointBaseCommon(CheckpointBase cp, int indent) {
		debugMap(indent, "Custom attributes:", cp.getCustomAttributes());
		CheckpointGroup parent = cp.getParent();
		if (parent != null) {
			debugPrint(indent, "Parent checkpoint group: " + parent.getShortName());
			debugPrint(indent + 1, "Identifier: " + parent.getIdentifier());
			debugPrint(indent + 1, "Full name: " + parent.getFullName());
			debugCheckpointBaseCommon(parent, indent + 1);
		}
	}

	private void debugMap(int indent, String header, Map<String, String> map) {
		if (!map.isEmpty()) {
			debugPrint(indent, header);
			SortedMap<String, String> sorted = new TreeMap<>(map);
			for (Map.Entry<String, String> entry : sorted.entrySet()) {
				debugPrint(indent + 1, entry.getKey() + " => " + entry.getValue());
			}
		}
	}

	private void debugPrint(int indent, String message) {
		for (int i = 0; i < indent; i++)
			out.print("  ");

		out.println(message);
	}
}
