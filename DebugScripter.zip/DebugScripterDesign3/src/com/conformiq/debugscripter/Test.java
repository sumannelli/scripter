package com.conformiq.debugscripter;



import org.apache.commons.collections4.MultiMapUtils;
import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;

public class Test {

	public static void main(String[] args) {
		
		 MultiValuedMap<String, String> map = new ArrayListValuedHashMap<>();
		    map.put("key1", "value1");
		    map.put("key1", "value2");
		    
		   /* MultiValuedMap<String, String> immutableMap =
		      MultiMapUtils.unmodifiableMultiValuedMap(map);
		 //   immutableMap.put("key1", "value3");
*/		    
		    System.out.println(map);
	}}
		/*
		
		XSSFWorkbook workbook = new XSSFWorkbook();
    	XSSFSheet sheet = workbook.createSheet("Example");
    	try {
			FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx");
			System.out.println("File created");
			try {
				workbook.write(outputStream);
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
	}*/

